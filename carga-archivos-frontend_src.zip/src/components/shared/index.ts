// Componentes compartidos reutilizables
export { UniversityHeader } from "./UniversityHeader";
export { UniversityHeaderOnly } from "./UniversityHeaderOnly";
export { NavigationTabs } from "./NavigationTabs";
export { Pagination } from "./Pagination";