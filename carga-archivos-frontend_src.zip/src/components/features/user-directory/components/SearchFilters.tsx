import React from "react";
import { Search } from "lucide-react";
import { SearchFiltersProps } from "@/types";

export function SearchFilters({
	searchTerm,
	roleFilter,
	showRoleDropdown,
	onSearchChange,
	onRoleFilterChange,
	onToggleRoleDropdown,
}: SearchFiltersProps) {
	const getRoleDisplayName = () => {
		if (!roleFilter) return "Rol";
		return roleFilter;
	};

	return (
		<div className="px-3 sm:px-6 py-3 sm:py-4">
			<div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-6">
				{/* Search */}
				<div className="relative w-full sm:w-auto">
					<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
					<input
						type="text"
						placeholder="Buscar"
						value={searchTerm}
						onChange={onSearchChange}
						className="w-full sm:w-60 pl-9 pr-3 py-2 border-2 border-gray-300 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm font-normal"
					/>
				</div>

				{/* Role Filter */}
				<div className="relative w-full sm:w-auto">
					<button
						onClick={onToggleRoleDropdown}
						className="flex items-center space-x-2 px-4 py-2 border-2 border-gray-300 rounded-full hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 text-sm min-w-[105px] w-full sm:w-auto justify-between font-normal"
					>
						<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M18.0407 16.5627C16.8508 14.5056 15.0172 13.0306 12.8774 12.3314C13.9358 11.7013 14.7582 10.7412 15.2182 9.59845C15.6781 8.45573 15.7503 7.19361 15.4235 6.00592C15.0968 4.81823 14.3892 3.77064 13.4094 3.02402C12.4296 2.2774 11.2318 1.87305 10 1.87305C8.76821 1.87305 7.57044 2.2774 6.59067 3.02402C5.6109 3.77064 4.90331 4.81823 4.57654 6.00592C4.24978 7.19361 4.32193 8.45573 4.78189 9.59845C5.24186 10.7412 6.06422 11.7013 7.12268 12.3314C4.98284 13.0299 3.14925 14.5049 1.9594 16.5627C1.91577 16.6338 1.88683 16.713 1.87429 16.7955C1.86174 16.878 1.86585 16.9622 1.88638 17.0431C1.9069 17.124 1.94341 17.2 1.99377 17.2665C2.04413 17.3331 2.10731 17.3889 2.17958 17.4306C2.25185 17.4724 2.33175 17.4992 2.41457 17.5096C2.49738 17.5199 2.58143 17.5136 2.66176 17.491C2.74209 17.4683 2.81708 17.4298 2.88228 17.3777C2.94749 17.3256 3.00161 17.261 3.04143 17.1877C4.51331 14.6439 7.11487 13.1252 10 13.1252C12.8852 13.1252 15.4867 14.6439 16.9586 17.1877C16.9985 17.261 17.0526 17.3256 17.1178 17.3777C17.183 17.4298 17.258 17.4683 17.3383 17.491C17.4186 17.5136 17.5027 17.5199 17.5855 17.5096C17.6683 17.4992 17.7482 17.4724 17.8205 17.4306C17.8927 17.3889 17.9559 17.3331 18.0063 17.2665C18.0566 17.2 18.0932 17.124 18.1137 17.0431C18.1342 16.9622 18.1383 16.878 18.1258 16.7955C18.1132 16.713 18.0843 16.6338 18.0407 16.5627ZM5.62503 7.50017C5.62503 6.63488 5.88162 5.78902 6.36235 5.06955C6.84308 4.35009 7.52636 3.78933 8.32579 3.4582C9.12522 3.12707 10.0049 3.04043 10.8535 3.20924C11.7022 3.37805 12.4818 3.79473 13.0936 4.40658C13.7055 5.01843 14.1222 5.79799 14.291 6.64665C14.4598 7.49532 14.3731 8.37499 14.042 9.17441C13.7109 9.97384 13.1501 10.6571 12.4306 11.1379C11.7112 11.6186 10.8653 11.8752 10 11.8752C8.84009 11.8739 7.72801 11.4126 6.90781 10.5924C6.0876 9.77219 5.62627 8.66011 5.62503 7.50017Z" fill="#2E4258"/>
						</svg>
						<span className="text-gray-700">{getRoleDisplayName()}</span>
						<svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
						</svg>
					</button>

					{showRoleDropdown && (
						<div className="absolute left-0 sm:right-0 mt-2 w-full sm:w-42 bg-white border border-gray-200 rounded-lg shadow-lg z-20">
							<div className="py-1">
								<button
									onClick={() => onRoleFilterChange("")}
									className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm border-b border-gray-100 font-normal"
								>
									N/A
								</button>
								<button
									onClick={() => onRoleFilterChange("Coordinador")}
									className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm border-b border-gray-100 font-normal"
								>
									Coordinador
								</button>
								<button
									onClick={() => onRoleFilterChange("Profesor")}
									className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm border-b border-gray-100 font-normal"
								>
									Profesor
								</button>
								<button
									onClick={() => onRoleFilterChange("Administrador")}
									className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm font-normal"
								>
									Administrador
								</button>
							</div>
						</div>
					)}
				</div>
			</div>
		</div>
	);
}